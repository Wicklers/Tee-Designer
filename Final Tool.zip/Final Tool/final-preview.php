<?php 
session_start();
  include('config.php');
?>  

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>T-Shirt</title>
		
	<link href="css/normalize.css" rel="stylesheet">
	
    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    
		<script src="js/jquery-1.10.2.js">	</script>
		<script src="js/bootstrap.js">		</script>
		
		<style>

</style>

</head>

<body>
<h2><a href="/">HOME</a></h2>
<div id="maindiv">
<?php

ini_set('display_errors', 1);
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // collect value of input field
    // Image Front
    if (isset($_POST['img_front'])) {
		$img_front = $_POST['img_front'];
		$img = str_replace('data:image/png;base64,', '', $img_front);
		$img = str_replace(' ', '+', $img);
		$data = base64_decode($img);
		$id = time().'_image.png';

		$_SESSION['imagepath'] = $id;

		file_put_contents($_SERVER['DOCUMENT_ROOT'].'/tdesignAPI/final_images/'.$id, $data);
		//$yourdesign = "/PHPConfigurator/tdesignAPI/final_images/".$id;
		echo "<img src='/tdesignAPI/final_images/".$id."' class='img_front' data-id='".$id."'>";
    }
}


  
if (isset($_POST['submit'])) {
	$imagepath = $_SESSION['imagepath'];
	$round = $_POST['round'];
	$NameYourDesign = $_POST['NameYourDesign'];
	$ContestDescription = $_POST['ContestDescription'];
	$FirstName = $_POST['FirstName'];
	$LastName = $_POST['LastName'];
	$Email = $_POST['Email'];
	$ConfirmEmail = $_POST['ConfirmEmail'];
	$Address = $_POST['Address'];
	$City = $_POST['City'];
	$ZipCode = $_POST['ZipCode'];
	$CountryState = $_POST['CountryState'];
	$DOB = $_POST['DOB'];
 	$Phone = $_POST['Phone'];

//echo $round . $NameYourDesign . $ContestDescription . $FirstName . $LastName . $Email . $ConfirmEmail . $Address . $City . $ZipCode . $CountryState . $DOB . $Phone; 	


$sql = "INSERT INTO users_contest_designs (contestround, nameofyourdesign, description, firstname, lastname, email, confirmemail, address, city, zipcode, state, dob, phone, yourdesign) VALUES ('$round', '$NameYourDesign', '$ContestDescription', '$FirstName', '$LastName', '$Email', '$ConfirmEmail', '$Address', '$City', '$ZipCode', '$CountryState', '$DOB', '$Phone', '$imagepath')";
 

//mailfunction
$to = "testing_accounts@leadingedgeinfosolutions.com";
$from = $Email;
$subject = "Round-".$round. ": Design Contest Registration From : ".$Email;

$message = '';
$message .= "Hey Admin,";
$message .= "<br><br><h4>A New Design From User</h4><br/>";
$message .= "<a href='https://abc.com/tdesignAPI/final_images/".$imagepath."'>See Design</a><br/>";
$message .= "Contest Round : ".$round. "<br/>";
$message .= "Name Of Design : ".$NameYourDesign. "<br/>";
$message .= "Describe Your Design : ".$ContestDescription. "<br/>";

$message .= "<hr/><br/>";
$message .= "First Name : ".$FirstName. "<br/>";
$message .= "Last Name : ".$LastName. "<br/>";
$message .= "Email : ".$Email. "<br/>";
$message .= "Confirm Email : ".$ConfirmEmail. "<br/>";
$message .= "Full Address : ".$Address. "<br/>";
$message .= "City : ".$City. "<br/>";
$message .= "ZipCode : ".$ZipCode. "<br/>";
$message .= "Country State : ".$CountryState. "<br/>";
$message .= "Date Of Birth : ".$DOB. "<br/>";
$message .= "Phone : ".$Phone. "<br/><br/>";
$message .= "<hr/><br/><br/><br/>";
$message .= "Thank You";

$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$headers .= "From:" . $from;


if(mail($to,$subject,$message,$headers)){  
	//echo "<h2 style='color:green;text-align: center;'></h2>". "<br/>";
	
}


if (mysqli_query($mysqli, $sql)) {
  //echo "<h2 style='color:green;text-align: center;'>You Will Get Update From Us On Your Email.</h2>". "<br/>";
	$_SESSION['successmsg']="Thank You For Your Submission In Contest.";
	header('Location:/',true);
} else {
  echo "Error: " . $sql . "<br>" . mysqli_error($mysqli);
}

mysqli_close($mysqli);

}	

?>
    <form method="POST"> 
    <p>Choose Your Contest Round</p>
	    <select id="round" name="round" id="round">
	        <option value="1" selected> 1 </option>
	        <option value="2"> 2 </option>	        
	        <option value="3"> 3 </option>
	        <option value="4"> 4  </option>
	        <option value="5"> 5  </option>	        
	    </select>    	
	    
    	<input type="text" id="NameYourDesign" required name="NameYourDesign" placeholder="Name Your Design"> 
    	<input type="textarea" id="ContestDescription" required name="ContestDescription" placeholder="Tell Us About Your Design">
    	<input type="text" id="FirstName" required name="FirstName" placeholder="First Name"> 
    	<input type="text" id="LastName" required name="LastName" placeholder="Last Name">     	
    	<input type="email" id="Email" required name="Email" placeholder="Email"> 
    	<input type="email" id="ConfirmEmail" required name="ConfirmEmail" placeholder="Confirm Email"> 
    	<input type="textarea" id="Address" required name="Address" placeholder="Full Address">    	
    	<input type="text" id="City" required name="City" placeholder="City"> 
    	<input type="text" id="ZipCode" required name="ZipCode" placeholder="ZipCode">     	
		<select id="CountryState" name="CountryState">
		    <option value="AL">Alabama</option>
		    <option value="AK">Alaska</option>
		    <option value="AS">American Samoa</option>
		    <option value="AZ">Arizona</option>
		    <option value="AR">Arkansas</option>
		    <option value="UM-81">Baker Island</option>
		    <option value="CA">California</option>
		    <option value="CO">Colorado</option>
		    <option value="CT">Connecticut</option>
		    <option value="DE">Delaware</option>
		    <option value="DC">District of Columbia</option>
		    <option value="FL">Florida</option>
		    <option value="GA">Georgia</option>
		    <option value="GU">Guam</option>
		    <option value="HI">Hawaii</option>
		    <option value="UM-84">Howland Island</option>
		    <option value="ID">Idaho</option>
		    <option value="IL">Illinois</option>
		    <option value="IN">Indiana</option>
		    <option value="IA">Iowa</option>
		    <option value="UM-86">Jarvis Island</option>
		    <option value="UM-67">Johnston Atoll</option>
		    <option value="KS">Kansas</option>
		    <option value="KY">Kentucky</option>
		    <option value="UM-89">Kingman Reef</option>
		    <option value="LA">Louisiana</option>
		    <option value="ME">Maine</option>
		    <option value="MD">Maryland</option>
		    <option value="MA">Massachusetts</option>
		    <option value="MI">Michigan</option>
		    <option value="UM-71">Midway Atoll</option>
		    <option value="MN">Minnesota</option>
		    <option value="MS">Mississippi</option>
		    <option value="MO">Missouri</option>
		    <option value="MT">Montana</option>
		    <option value="UM-76">Navassa Island</option>
		    <option value="NE">Nebraska</option>
		    <option value="NV">Nevada</option>
		    <option value="NH">New Hampshire</option>
		    <option value="NJ">New Jersey</option>
		    <option value="NM">New Mexico</option>
		    <option value="NY">New York</option>
		    <option value="NC">North Carolina</option>
		    <option value="ND">North Dakota</option>
		    <option value="MP">Northern Mariana Islands</option>
		    <option value="OH">Ohio</option>
		    <option value="OK">Oklahoma</option>
		    <option value="OR">Oregon</option>
		    <option value="UM-95">Palmyra Atoll</option>
		    <option value="PA">Pennsylvania</option>
		    <option value="PR">Puerto Rico</option>
		    <option value="RI">Rhode Island</option>
		    <option value="SC">South Carolina</option>
		    <option value="SD">South Dakota</option>
		    <option value="TN">Tennessee</option>
		    <option value="TX">Texas</option>
		    <option value="UM">United States Minor Outlying Islands</option>
		    <option value="VI">United States Virgin Islands</option>
		    <option value="UT">Utah</option>
		    <option value="VT">Vermont</option>
		    <option value="VA">Virginia</option>
		    <option value="UM-79">Wake Island</option>
		    <option value="WA">Washington</option>
		    <option value="WV">West Virginia</option>
		    <option value="WI">Wisconsin</option>
		    <option value="WY">Wyoming</option>
		</select>    	
		<input type="date" id="dob" name="DOB" placeholder="Date Of Birth">
		<input type="text" id="phone" name="Phone" placeholder="Phone">
        <input type="submit" name="submit" value="Submit">
    </form>
	</div>
</body>
<style type="text/css">
input {
	display: block
}
</style>
</html>
