<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>TalkInTee</title>
		
	<link href="css/normalize.css" rel="stylesheet">
	
    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    
		<script src="js/jquery-1.10.2.js">	</script>
		<script src="js/bootstrap.js">		</script>
		
		<style>

</style>

</head>

<body>
		<h2><a href="/">HOME</a></h2>
	<div id="maindiv">
<!--
<p><strong>Design the new Krystal Crew T-shirt and you could win:</strong></p>
<h3 style="margin-left:0px;">1. Grand Prize:</h3>
<ul>
    <li>Winner will receive <strong>$10,000</strong>. Plus, your Krystal shirt design will be proudly worn by Krystal employees in more than 380 stores accross the Southeast.</li>
</ul>
<h3 style="margin-left:0px;">2. Second Prize:</h3>
<ul>
    <li>Winner will receive <strong>$1,500</strong>.</li>
</ul>
<h3 style="margin-left:0px;">3. Third Prize:</h3>
<ul>
    <li>Winner will receive <strong>$500</strong>.</li>
</ul>
<h3 style="margin-left:0px;">4. Judges' Choice Award:</h3>
<ul>
    <li>Top 20 designs will receive honorable mentions.</li>
</ul>
-->
		
<?php
	if(isset($_SESSION['successmsg']))
		{
		 echo "<h2 style='color:green;text-align: center;'>".$_SESSION['successmsg']."</h2>";
		 echo "<h3 style='color:green;text-align: center;'>You Will Get Update From Us On Your Email.</h3>";		 
		 unset($_SESSION['successmsg']);
		}		
	include 'tdesignAPI/new_applit.php';
?>
<!--
<h3 style="margin-left:0px;">How to get started:</h3>
<p style="margin-left:0px;">All designs must be created and submitted using our easy Online Design program to ensure that your design will be printable should it win.</p>
<p style="margin-left:0px;">To begin designing, simply <a href="http://krystal.novaredigital.com/contests/design-a-shirt/editor">click here</a>. The Online Design Program provides a complete set of easy-to-use design tools, clip art and upload feature to add your own photos or art, giving you the freedom to express yourself.</p>
<p style="margin-left:0px;">Please download and review the complete <a href="http://krystal.novaredigital.com/contests/images/design-a-shirt/Artwork_Eligibility.pdf">Artwork and Design Eligibility</a> document to ensure your design entry qualifies.</p>

<h3 style="margin-left:0px;">Judging</h3>
<p><span style="background-color:rgb(255,255,255);color:rgb(0,0,0);font-family:Arial, Helvetica, sans-serif;">A panel of 5 Official Krystal Judges will review every entry and judge them according to originality, creativity, and passion for the Krystal brand as follows:</span></p>
<ul>
    <li><strong>25% – Popularity</strong></li>
    <li><strong>25% – Overall design quality</strong></li>
    <li><strong>25% – Use of Krystal brand elements</strong></li>
    <li><strong>25% – Originality</strong></li>
</ul>
<h3 style="margin-left:0px;">Deadline</h3>
<p style="margin-left:0px;">All submissions must be completed on or before:</p>
<h2 style="margin-left:0px;">September 25, 2022</h2>
<h3 style="margin-left:0px;"><br>Winner notification</h3>
<p style="margin-left:0px;">Krystal will announce the winners on October 5, 2022.</p>
<h3 style="margin-left:0px;">What to do if your design is declined</h3>
<p style="margin-left:0px;">If your design has been declined, you may submit another design as long as the deadline has not expired.</p>
-->		
	</div>
	
</body>
		
</html>
