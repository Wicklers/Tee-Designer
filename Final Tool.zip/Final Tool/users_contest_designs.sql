-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jan 07, 2022 at 03:28 PM
-- Server version: 5.7.21-21
-- PHP Version: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `javamarkdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `users_contest_designs`
--

CREATE TABLE `users_contest_designs` (
  `id` int(11) NOT NULL,
  `contestround` int(5) NOT NULL,
  `nameofyourdesign` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `email` varchar(200) NOT NULL,
  `confirmemail` varchar(100) NOT NULL,
  `address` varchar(200) NOT NULL,
  `city` varchar(100) NOT NULL,
  `zipcode` varchar(10) NOT NULL,
  `state` varchar(100) NOT NULL,
  `dob` date NOT NULL,
  `phone` double NOT NULL,
  `yourdesign` varchar(255) NOT NULL,
  `submitdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users_contest_designs`
--

INSERT INTO `users_contest_designs` (`id`, `contestround`, `nameofyourdesign`, `description`, `firstname`, `lastname`, `email`, `confirmemail`, `address`, `city`, `zipcode`, `state`, `dob`, `phone`, `yourdesign`, `submitdate`) VALUES
(1, 1, 'test', 'testdesc', 'harry', 'leis', 'harry@leis.com', 'harry@leis.com', 'leismohali', 'mohali', '143007', 'PB', '0000-00-00', 1234567890, 'testpathofimage', '2022-01-06 08:16:01'),
(2, 1, 'Test den', 'ggggggggggggg', '', '', '', '', '', '', '', '', '0000-00-00', 0, '', '2022-01-06 10:23:26'),
(3, 2, 'sdfsdfsdf', 'ggggggggggggg', 'Test', 'den', 'testing_accounts@leadingedgeinfosolutions.com', 'testing_accounts@leadingedgeinfosolutions.com', '6 Rue Balzac, 75008 Paris, France, tom address, tom address', 'Paris ', '75008', 'AL', '1993-02-13', 123456789, '', '2022-01-06 10:36:03'),
(4, 2, 'Test den', 'asdasdasd', 'Test', 'den', 'testing_accounts@leadingedgeinfosolutions.com', 'testing_accounts@leadingedgeinfosolutions.com', '6 Rue Balzac, 75008 Paris, France, tom address, tom address', 'Paris ', '75008', 'AL', '1990-04-06', 123456789, '', '2022-01-06 10:36:39'),
(5, 1, 'Test den', 'asdasdasd', 'Test', 'den', 'sr@leadingedgeinfosolutions.com', 'sr@leadingedgeinfosolutions.com', '6 Rue Balzac, 75008 Paris, France, tom address, tom address', 'Paris ', '75008', 'AL', '1996-05-28', 123456789, '', '2022-01-06 10:39:24'),
(6, 1, 'harr', 'haseaseasragasg', 'Test', 'den', 'harr@ymail.com', 'harr@ymail.com', '6 Rue Balzac, 75008 Paris, France, tom address, tom address', 'Paris ', '75008', 'AL', '1990-04-08', 123456789, '', '2022-01-06 10:40:57'),
(7, 5, 'hari den', 'test design hari', 'harri', 'den', 'hari@gmail.com', 'hari@gmail.com', 'Delacorte Theater Central Park West NY America', 'New York ', '10023', 'AL', '2007-01-14', 987, '1641466019_image.png', '2022-01-06 10:46:59'),
(8, 1, 'John Smith', 'asdajskdajsdkajsdkjkjad', 'John', 'Smith', 'lesigaints@gmail.com', 'lesigaints@gmail.com', '132 Gibbs St, East Cannington, WA 6107 Australia', 'East Cannington ', '6107', 'AL', '1977-04-06', 408902726, '1641466600_image.png', '2022-01-06 10:56:40'),
(9, 4, 'KYC', 'KYC', 'Test', 'den', 'testing_accounts@leadingedgeinfosolutions.com', 'testing_accounts@leadingedgeinfosolutions.com', '6 Rue Balzac, 75008 Paris, France, tom address, tom address', 'Paris ', '75008', 'AL', '2001-02-09', 123456789, '', '2022-01-06 12:07:13'),
(10, 1, 'testing', 'test', 'developer', 'testing', 'testing_accounts@leadingedgeinfosolutions.com', 'testing_accounts@leadingedgeinfosolutions.com', 'Mohali', 'Mohali', '140301', 'AL', '2022-01-06', 202222, '1641472666_image.png', '2022-01-06 12:37:46'),
(11, 1, 'testing', 'test', 'developer', 'testing', 'testing_accounts@leadingedgeinfosolutions.com', 'testing_accounts@leadingedgeinfosolutions.com', 'Mohali', 'Mohali', '140301', 'AL', '2022-01-07', 122041204, '1641473090_image.png', '2022-01-06 12:45:05'),
(12, 4, 'John Smith', 'jhjhkhjkjhkhjk', 'John', 'Smith', 'firefliesu4@gmail.com', 'firefliesu4@gmail.com', '132 Gibbs St, East Cannington, WA 6107 Australia', 'East Cannington', '6107', 'AL', '2022-01-27', 408902726, '1641474455_image.png', '2022-01-06 13:07:51'),
(13, 1, 'Test den', 'qweqweqwe', 'Test', 'den', 'testing_accounts@leadingedgeinfosolutions.com', 'testing_accounts@leadingedgeinfosolutions.com', '6 Rue Balzac, 75008 Paris, France, tom address, tom address', 'Paris', '75008', 'AL', '2022-01-08', 123456789, '1641474455_image.png', '2022-01-06 13:09:55'),
(14, 1, 'Test den kyc', 'kyc', 'Test', 'den', 'testing_accounts@leadingedgeinfosolutions.com', 'testing_accounts@leadingedgeinfosolutions.com', '6 Rue Balzac, 75008 Paris, France, tom address, tom address', 'Paris', '75008', 'AL', '1990-12-31', 123456789, '1641534604_image.png', '2022-01-07 05:51:24'),
(15, 1, 'HUD John Smith', 'jhjhkhjkjhkhjk', 'John', 'Smith', 'firefliesu4@gmail.com', 'firefliesu4@gmail.com', '132 Gibbs St, East Cannington, WA 6107 Australia', 'East Cannington', '6107', 'AL', '2022-01-06', 408902726, '1641536374_image.png', '2022-01-07 06:19:57'),
(16, 1, 'Test den', 'jkjkjkooioioi', 'Test', 'den', 'testing_accounts@leadingedgeinfosolutions.com', 'testing_accounts@leadingedgeinfosolutions.com', '6 Rue Balzac, 75008 Paris, France, tom address, tom address', 'Paris', '75008', 'AL', '2022-01-06', 123456789, '1641537241_image.png', '2022-01-07 06:34:15'),
(17, 3, 'Bi', 'wi', 'bi', 'wi', 'carterjamese88@gmail.com', 'carterjamese88@gmail.com', 'Delacorte Theater Central Park West NY A', 'New York', '10023', 'AL', '2022-01-06', 9874563210, '1641539358_image.png', '2022-01-07 07:09:43'),
(18, 4, 'Test den', 'jhjhkhjkjhkhjk', 'Test', 'den', 'testing_accounts@leadingedgeinfosolutions.com', 'testing_accounts@leadingedgeinfosolutions.com', '6 Rue Balzac, 75008 Paris, France, tom address, tom address', 'Paris', '75008', 'AL', '2022-01-06', 123456789, '1641540180_image.png', '2022-01-07 07:23:24'),
(19, 1, 'James', 'james bond fan', 'james', 'bond', 'james007@jamesbond.com', 'james007@jamesbond.com', '6 Rue Balzac, 75008 Paris, France, tom address, tom address', 'USA', '75008', 'AR', '2021-12-29', 123456789, '1641540468_image.png', '2022-01-07 07:29:06'),
(20, 3, 'john den', 'bg', 'john', 'den', 'jonesmick841@gmail.com', 'jonesmick841@gmail.com', 'Delacorte Theater Central Park West NY America', 'New York', '10023', 'AL', '2022-01-29', 987, '1641541113_image.png', '2022-01-07 07:38:47'),
(21, 1, 'Test den', 'Test den', 'Test', 'den', 'dav@aol.com', 'dav@aol.com', '6 Rue Balzac, 75008 Paris, France, tom address, tom address', 'India', '75008', 'AL', '2022-01-06', 123456789, '1641541362_image.png', '2022-01-07 07:43:13'),
(22, 1, 'Test asdasdasdasd', 'asdasdasdasdasd', 'Test', 'den', 'testing_accounts@leadingedgeinfosolutions.com', 'testing_accounts@leadingedgeinfosolutions.com', '6 Rue Balzac, 75008 Paris, France, tom address, tom address', 'Paris', '75008', 'AL', '2022-01-29', 123456789, '1641541581_image.png', '2022-01-07 07:46:35'),
(23, 3, 'John Smith', 'ddddddddddfdfdfdfdfdf', 'John', 'Smith', 'firefliesu4@gmail.com', 'firefliesu4@gmail.com', '132 Gibbs St, East Cannington, WA 6107 Australia', 'East Cannington', '6107', 'IA', '2021-12-29', 408902726, '1641542216_image.png', '2022-01-07 07:57:16'),
(24, 1, 'vvp', 'uipuip', 'vvp', 'vip', 'aoldasd@ymail.com', 'aoldasd@ymail.com', '6 Rue Balzac, 75008 Paris, France', 'Paris', '75008', 'AL', '2022-01-20', 9874563210, '1641542590_image.png', '2022-01-07 08:03:41'),
(25, 1, 'John Testers Testers Smith', 'ggggggggggggg', 'John Testers', 'Smith', 'testing_accounts@leadingedgeinfosolutions.com', 'testing_accounts@leadingedgeinfosolutions.com', '132 Gibbs St, East Cannington, WA 6107 Australia', 'East Cannington', '6107', 'AL', '2022-01-28', 33123456789, '1641543247_image.png', '2022-01-07 08:14:18'),
(26, 1, 'Lincoln NE', 'aasdadad', 'Lincoln', 'NE', 'info@garagedoorrepairlincolnne.com', 'info@garagedoorrepairlincolnne.com', 'Anytime Garage Door Repair Lincolnâ€“ Garage Door Re', 'Lincoln', '68508', 'AL', '2022-01-29', 4024136135, '1641543446_image.png', '2022-01-07 08:17:38'),
(27, 2, 'Lincoln NE', 'aaaaaaaaaa', 'Lincoln', 'NE', 'info@garagedoorrepairlincolnne.com', 'info@garagedoorrepairlincolnne.com', 'Anytime Garage Door Repair Lincolnâ€“ Garage Door Re', 'Lincoln', '68508', 'AL', '2022-01-28', 4024136135, '1641547986_image.png', '2022-01-07 09:33:23'),
(28, 3, 'Lincoln NE', 'h', 'Lincoln', 'NE', 'info@garagedoorrepairlincolnne.com', 'info@garagedoorrepairlincolnne.com', 'Anytime Garage Door Repair Lincolnâ€“ Garage Door Re', 'Lincoln', '68508', 'AL', '2022-01-28', 4024136135, '1641548153_image.png', '2022-01-07 09:36:04');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users_contest_designs`
--
ALTER TABLE `users_contest_designs`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users_contest_designs`
--
ALTER TABLE `users_contest_designs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
